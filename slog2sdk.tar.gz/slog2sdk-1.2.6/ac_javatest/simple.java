public class simple {
    public static void main( String args[] )
    {
        System.exit( 0 );
    }
}
